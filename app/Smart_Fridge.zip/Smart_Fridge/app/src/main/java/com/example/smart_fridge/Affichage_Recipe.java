package com.example.smart_fridge;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Affichage_Recipe extends AppCompatActivity {

    private TextView recipeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affichage_recipe);
        recipeTextView = findViewById(R.id.recipeTextView);
        Intent intent = getIntent();
        if (intent != null) {
            String recipesString = intent.getStringExtra("recipes");
            recipeTextView.setText(recipesString);
        }
    }
}
